# PPG_PCG_ESP32
PPG and PCG measurement project. In this project, I use MAX30102 to measure PPG signal and INMP441 for PCG. 
This project requires program to run at high frequency to receives a large mount of data. We want frequency of PPG signal is 250Hz when PCG's frequency can reach up to 4000Hz.
